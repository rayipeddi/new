var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4a569bd1-d755-4154-ba0e-46fc08063c1f","942ef0e4-854d-4fe4-9efb-dad80d0d77a8","a782cbb1-433d-4b18-813c-86a4ad57098a","2f7cd414-65c8-4412-a849-9730643e7f0e","8bf5ed51-3ba1-4e08-8d74-93f7f41de5b0","922a971e-d883-411e-8ae9-b6faad83c468","da494998-2521-4a1e-bfa9-43145fe73296","b90b5292-e089-4a85-9ace-13a954546a2a","17ef8c39-9c9d-466e-a454-158cf89906ee","6bb5a3e9-f4f1-438e-950a-d460eecb45da","3c6a0105-ee77-4a65-a218-1ff9b12b0cc3"],"propsByKey":{"4a569bd1-d755-4154-ba0e-46fc08063c1f":{"name":"1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"2ZiaO_GSEv8eojudgRKpxuy9hlMvqHUT","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/4a569bd1-d755-4154-ba0e-46fc08063c1f.png"},"942ef0e4-854d-4fe4-9efb-dad80d0d77a8":{"name":"2","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"8MH1uvoAyfM3t_RhXRodUJF0W87JAdfm","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/942ef0e4-854d-4fe4-9efb-dad80d0d77a8.png"},"a782cbb1-433d-4b18-813c-86a4ad57098a":{"name":"3","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"as_zBTGAq_2L_AQfsLq9dEldn6JEJ0Wm","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/a782cbb1-433d-4b18-813c-86a4ad57098a.png"},"2f7cd414-65c8-4412-a849-9730643e7f0e":{"name":"4","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"ntLc27ruwOrSU.SNkzv4Jk0jUYSyy0Fm","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/2f7cd414-65c8-4412-a849-9730643e7f0e.png"},"8bf5ed51-3ba1-4e08-8d74-93f7f41de5b0":{"name":"5","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"gl_z48l.7G_p_TAv2OYYVYflbhrW1uRB","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/8bf5ed51-3ba1-4e08-8d74-93f7f41de5b0.png"},"922a971e-d883-411e-8ae9-b6faad83c468":{"name":"6","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"2uMhpzp4MuB67TccU3MCTUmMGQAMi.3Z","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/922a971e-d883-411e-8ae9-b6faad83c468.png"},"da494998-2521-4a1e-bfa9-43145fe73296":{"name":"7","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"JH43JnQI.MdqqcZSCtwtooy_mQrVJuKv","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/da494998-2521-4a1e-bfa9-43145fe73296.png"},"b90b5292-e089-4a85-9ace-13a954546a2a":{"name":"8","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"34vwuQlopUyErLtLcNRd0RM55G6JZC31","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/b90b5292-e089-4a85-9ace-13a954546a2a.png"},"17ef8c39-9c9d-466e-a454-158cf89906ee":{"name":"9","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"VcLsV9uEzM97FLY2wfXD5y7SbcMGDIA0","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/17ef8c39-9c9d-466e-a454-158cf89906ee.png"},"6bb5a3e9-f4f1-438e-950a-d460eecb45da":{"name":"10","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"ls_7c9Jm31rOQpYszOlb34pFhCzck11F","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/6bb5a3e9-f4f1-438e-950a-d460eecb45da.png"},"3c6a0105-ee77-4a65-a218-1ff9b12b0cc3":{"name":"heart","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"Hjjre1D7UtqNVozoWsts8IBfJvXXDyQi","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/3c6a0105-ee77-4a65-a218-1ff9b12b0cc3.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ballons, ballonsGroup;
var rand
var color
function draw() {
 background("pink");
 
 if(World.frameCount % 25 === 0){
    ballons = createSprite(200,350,10,10)
    ballons.x = Math.round(random(50,350))
    ballons.velocityY = -2
     rand = Math.round(random(1,6))
    switch(rand){
      case 1: ballons.setAnimation("1")
      break
      case 2: ballons.setAnimation("2")
      break
      case 3: ballons.setAnimation("3")
      break
      case 4: ballons.setAnimation("4")
      break
      case 5: ballons.setAnimation("5")
      break
      case 6: ballons.setAnimation("6")
      break
      default:break
    }
 }
 
 color = Math.round(random(1,4))
 switch(color){
   case 1: textSize(30)
   stroke("red")
   text("HAPPY GRANDPARENTS'",25,200 )
   textSize(30)
   stroke("red")
   text("DAY BUJJI!!",120,250)
   break
   case 2: textSize(30)
   stroke("purple")
   text("HAPPY GRANDPARENTS'",25,200 )
   textSize(30)
   stroke("purple")
   text("DAY BUJJI!!",120,250)
   break
   case 3: textSize(30)
   stroke("green")
   text("HAPPY GRANDPARENTS'",25,200 )
   textSize(30)
   stroke("green")
   text("DAY BUJJI!!",120,250)
   break
   case 4: textSize(30)
   stroke("blue")
   text("HAPPY GRANDPARENTS'",25,200 )
   textSize(30)
   stroke("blue")
   text("DAY BUJJI!!",120,250)
   break
   default:break
 }
 drawSprites();
}
function spawnBallon(){
  if(World.frameCount % 100 === 0){
    ballons = createSprite(200,200,10,10)
    var rand = Math.round(random(1,6))
    switch(rand){
      case 1: ballon.setAnimation("1")
      break
      case 2: ballon.setAnimation("2")
      break
      case 3: ballon.setAnimation("3")
      break
      case 4: ballon.setAnimation("4")
      break
      case 5: ballon.setAnimation("5")
      break
      case 6: ballon.setAnimation("6")
      break
      default:break
    }
    
  }
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
